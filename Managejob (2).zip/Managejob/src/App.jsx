import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "./App.css";
import Header from "./components/Header/Header";
import Home from "./components/Home/Home";
import Services from "./components/Services/Services";

// These are the service pages (create these components if you haven't)
import JobSearchAssistance from "./components/JobSearchAssistance/JobSearchAssistance";
import ResumeBuilder from "./components/ResumeBuilder/ResumeBuilder";
import InterviewPreparation from "./components/InterviewPreparation/InterviewPreparation";

function App() {
  return (
    <Router>
      <>
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/job-search-assistance" element={<JobSearchAssistance />} />
          <Route path="/resume-builder" element={<ResumeBuilder />} />
          <Route path="/interview-preparation" element={<InterviewPreparation />} />
        </Routes>
      </>
    </Router>
  );
}

export default App;
