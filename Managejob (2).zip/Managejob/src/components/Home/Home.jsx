import React from 'react';
import './home.css';

function Home() {
  return (
    <div>
      <section id="hero">
        <h1>Search jobs now</h1>
        <p>ManageJob.com</p>
        <div className="search-bar">
          <input type="text" placeholder="Enter skills / designations / companies" />
          <div className="separator"></div>
          <input type="text" placeholder="Select experience" />
          <div className="separator"></div>
          <input type="text" placeholder="Enter location" />
          <button>Search</button>
        </div>
      </section>

      <section id="mock-interview">
        <div className="mock-interview-banner">
          <div className="mock-text">
            <h2>Practice customised mock interview with AI!</h2>
            <p>Your result will be visible only to you</p>
            <a href="#">Start for free</a>
          </div>
          <img src="images/mock-interview.png" alt="Mock Interview" />
        </div>
      </section>

      <section id="categories">
        <div className="category">
          <a href="#">
            <i className="fa fa-home"></i> Remote 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-building"></i> MNC 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-rocket"></i> Startup 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-truck"></i> Supply Chain 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-chart-line"></i> Marketing 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-chart-pie"></i> Analytics 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-handshake"></i> Fortune 500
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-database"></i> Data Science 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-users"></i> HR 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-graduation-cap"></i> Internship 
          </a>
        </div>
        <div className="category">
          <a href="#">
            <i className="fa fa-user-graduate"></i> Fresher 
          </a>
        </div>
      </section>

      <section id="top-companies">
        <h2>Top companies hiring now</h2>
        <div className="company-cards">
          <div className="company-card">
            <h3>MNCs</h3>
            <p>2.1k+ are actively hiring</p>
            <div className="company-logos">
              <img src="images/company1.png" alt="Company 1" />
              <img src="images/company2.png" alt="Company 2" />
              <img src="images/company3.png" alt="Company 3" />
            </div>
          </div>
          <div className="company-card">
            <h3>Fintech</h3>
            <p>123 are actively hiring</p>
            <div className="company-logos">
              <img src="images/company4.png" alt="Company 4" />
              <img src="images/company5.png" alt="Company 5" />
              <img src="images/company6.png" alt="Company 6" />
            </div>
          </div>
          <div className="company-card">
            <h3>FMCG & Retail</h3>
            <p>136 are actively hiring</p>
            <div className="company-logos">
              <img src="images/company7.png" alt="Company 7" />
              <img src="images/company8.png" alt="Company 8" />
              <img src="images/company9.png" alt="Company 9" />
            </div>
          </div>
          <div className="company-card">
            <h3>Startups</h3>
            <p>577 are actively hiring</p>
            <div className="company-logos">
              <img src="images/company10.png" alt="Company 10" />
              <img src="images/company11.png" alt="Company 11" />
              <img src="images/company12.png" alt="Company 12" />
            </div>
          </div>
          <div className="company-card">
            <h3>Edtech</h3>
            <p>147 are actively hiring</p>
            <div className="company-logos">
              <img src="images/company13.png" alt="Company 13" />
              <img src="images/company14.png" alt="Company 14" />
              <img src="images/company15.png" alt="Company 15" />
            </div>
          </div>
        </div>
      </section>

      <section id="featured-companies">
        <h2>Featured companies actively hiring</h2>
        <div className="company-slider">
          <div className="company-card">
            <img src="images/cognizant.png" alt="Cognizant" />
            <h3>Cognizant</h3>
            <p>
              <i className="fas fa-star"></i> 3.8 49.9k+ reviews
            </p>
            <p>Leading IT/ITeS company with global presence.</p>
            <a href="#">View jobs</a>
          </div>
          <div className="company-card">
            <img src="images/hitachi.png" alt="Hitachi" />
            <h3>Hitachi Energy</h3>
            <p>
              <i className="fas fa-star"></i> 4.1 672 reviews
            </p>
            <p>Advancing a sustainable energy future for all.</p>
            <a href="#">View jobs</a>
          </div>
          <div className="company-card">
            <img src="images/datamatics.png" alt="Datamatics" />
            <h3>Datamatics</h3>
            <p>
              <i className="fas fa-star"></i> 3.5 24+ reviews
            </p>
            <p>Global digital solutions & technology company.</p>
            <a href="#">View jobs</a>
          </div>
          <div className="company-card">
            <img src="images/jio.png" alt="Jio" />
            <h3>Jio</h3>
            <p>
              <i className="fas fa-star"></i> 3.9 22.6k+ reviews
            </p>
            <p>True 5G is here to unlock the limitless era.</p>
            <a href="#">View jobs</a>
          </div>
          <div className="company-card">
            <img src="images/abc.png" alt="Abc" />
            <h3>Abc Consulting</h3>
            <p>
              <i className="fas fa-star"></i> 4.0 9k+ reviews
            </p>
            <p>Leading global consulting company.</p>
            <a href="#">View jobs</a>
          </div>

          <div className="company-card">
            <img src="images/cognizant.png" alt="Cognizant" />
            <h3>Cognizant</h3>
            <p>
              <i className="fas fa-star"></i> 3.8 49.9k+ reviews
            </p>
            <p>Leading IT/ITeS company with global presence.</p>
            <a href="#">View jobs</a>
          </div>
          <div className="company-card">
            <img src="images/hitachi.png" alt="Hitachi" />
            <h3>Hitachi Energy</h3>
            <p>
              <i className="fas fa-star"></i> 4.1 672 reviews
            </p>
            <p>Advancing a sustainable energy future for all.</p>
            <a href="#">View jobs</a>
          </div>
        </div>
        <a href="#" className="view-all-companies">
          View all companies
        </a>
      </section>

      <section id="scholarship">
        <img src="images/scholarship-banner.png" alt="Scholarship Banner" />
      </section>

      <footer>
        <p>© 2025 ManageJob</p>
      </footer>

      <script src="script.js"></script>
    </div>
  );
}

export default Home;