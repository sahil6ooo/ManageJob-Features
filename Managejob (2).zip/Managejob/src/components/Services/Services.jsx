import { Link } from "react-router-dom"; // Import Link for navigation
import "./Services.css"; // Importing the CSS file for styling

const servicesData = [
  {
    icon: "fas fa-search",
    title: "Job Search Assistance",
    description: "Find your dream job with AI-powered recommendations.",
    path: "/job-search-assistance",
  },
  {
    icon: "fas fa-file-alt",
    title: "Resume Building",
    description: "Get a professionally crafted resume to stand out.",
    path: "/resume-builder",
  },
  {
    icon: "fas fa-comments",
    title: "Interview Preparation",
    description:
      "Mock interviews, tips, and expert guidance to ace your interview.",
    path: "/interview-preparation",
  },
];

const Services = () => {
  return (
    <section className="services-container">
      <h2 className="section-title">Our Premium Services</h2>
      <div className="services-grid">
        {servicesData.map((service, index) => (
          <div className="service-card" key={index}>
            <div className="icon-wrapper">
              <i className={service.icon} aria-hidden="true"></i>
            </div>
            <h3 className="service-title">{service.title}</h3>
            <p className="service-description">{service.description}</p>
            <Link to={service.path} className="learn-more" role="button">
              Explore More
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Services;
