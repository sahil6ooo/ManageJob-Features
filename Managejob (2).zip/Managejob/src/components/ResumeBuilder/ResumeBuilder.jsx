import React from 'react';
import './ResumeBuilder.css';

const ResumeBuilder = () => {
  return (
    <div className="resume-builder-container">
      <h1>📄 Resume Builder</h1>
      <p>Create a professional resume with expert templates and real-time feedback.</p>

      <div className="resume-feature">
        <h3>🎨 Beautiful Templates</h3>
        <p>Choose from modern, creative, and professional designs.</p>
      </div>

      <div className="resume-feature">
        <h3>🔍 AI Feedback</h3>
        <p>Get instant suggestions to improve your resume content.</p>
      </div>

      <div className="resume-feature">
        <h3>📥 Download in Multiple Formats</h3>
        <p>Export your resume in PDF, DOCX, and more.</p>
      </div>

      <button className="back-btn" onClick={() => window.history.back()}>Back to Services</button>
    </div>
  );
};

export default ResumeBuilder;
