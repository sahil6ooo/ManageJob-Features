import React from 'react';
import './JobSearchAssistance.css';

const JobSearchAssistance = () => {
  return (
    <div className="job-search-container">
      <h1>🚀 Job Search Assistance</h1>
      <p>We help you find your dream job with personalized recommendations, daily alerts, and expert guidance.</p>

      <div className="feature-box">
        <h3>✨ Personalized Job Matches</h3>
        <p>AI-powered recommendations tailored to your skills and goals.</p>
      </div>

      <div className="feature-box">
        <h3>📩 Daily Job Alerts</h3>
        <p>Stay updated with real-time job postings in your field.</p>
      </div>

      <div className="feature-box">
        <h3>📄 Resume & Cover Letter Tips</h3>
        <p>Expert suggestions to enhance your applications.</p>
      </div>

      <button className="back-btn" onClick={() => window.history.back()}>Back to Services</button>
    </div>
  );
};

export default JobSearchAssistance;
