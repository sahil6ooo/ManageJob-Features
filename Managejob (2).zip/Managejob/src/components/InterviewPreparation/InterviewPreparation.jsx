import React from 'react';
import './InterviewPreparation.css';

const InterviewPreparation = () => {
  return (
    <div className="interview-prep-container">
      <h1>🎤 Interview Preparation</h1>
      <p>Ace your interviews with expert-curated Q&As, mock tests, and feedback.</p>

      <div className="interview-feature">
        <h3>📚 Expert Q&A</h3>
        <p>Practice with real interview questions tailored to your field.</p>
      </div>

      <div className="interview-feature">
        <h3>🎥 Mock Interviews</h3>
        <p>Simulate real interviews and receive expert feedback.</p>
      </div>

      <div className="interview-feature">
        <h3>✅ Confidence Boosting Tips</h3>
        <p>Learn the dos and don'ts for interview success.</p>
      </div>

      <button className="back-btn" onClick={() => window.history.back()}>Back to Services</button>
    </div>
  );
};

export default InterviewPreparation;
